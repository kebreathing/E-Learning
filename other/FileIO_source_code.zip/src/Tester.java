import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Chris 龙东恒
 * @mail kebreathing@gmail.com
 * @date 2017/11/18 14:13
 */
public class Tester {

    /**
     * 测试单个股票文件
     *
     * @param filename
     */
    public static void test_file(String filename) {
        CSVReader reader = new CSVReader();
        // 读取股票数据 并分类
        StockInfo si = reader.read(filename);
        // 找到2013、2014最大收益股票
        System.out.println(si.findMaxInYear(2013));
//        System.out.println(si.findMaxInYear(2014));
        // 找到2013年8月最大收益股票
//        System.out.println(si.findMaxInYear_Month(2013, 8));
        // 找到2014年4月所有股票信息
        List<StockBean> ss = si.getStockInYear_Month(2013, 4);
        System.out.println(ss.size());
    }

    /**
     * 获得指定类型在指定年份中的最大收益股票(单线程)
     *
     * @param types
     * @param years
     * @param dirpath
     * @return
     */
    public static Map<String, StockBean> test_dir(String[] types, int[] years, String dirpath) {
        long start = System.currentTimeMillis();
        List<StockInfo> ss = new CSVReader().read_patch(dirpath);
        Map<String, StockBean> map = new HashMap<>();

        if (ss == null) {
            System.out.println("{ " + dirpath + " } can not read from this directory.");
            return null;
        }

        for (StockInfo si : ss) {
            String type = si.getType();
            for (int year : years) {
                String key = genKey(type, year);
                StockBean s = si.findMaxInYear(year);
                // 初始化：同类型同年份没有最大利益值
                if (!map.containsKey(key)) {
                    map.put(key, si.findMaxInYear(year));
                } else if (s != null && map.get(key).getBenefit() < s.getBenefit()) {
                    // 存在有些stock缺乏年月信息
                    map.put(key, s);
                }

            }
        }

        System.out.println(map);
        System.out.println("Single:" + (System.currentTimeMillis() - start));
        return map;
    }

    /**
     * 多线程
     * @param types
     * @param years
     * @param dirpath
     * @return
     */
    public static Map<String, StockBean> test_dir_thread(String[] types, int[] years, String dirpath) {
        long start = System.currentTimeMillis();
        List<StockInfo> ss = new CSVReader().read_patch_thread(dirpath);
        Map<String, StockBean> map = new HashMap<>();

        if (ss == null) {
            System.out.println("{ " + dirpath + " } can not read from this directory.");
            return null;
        }

        for (StockInfo si : ss) {
            String type = si.getType();
            for (int year : years) {
                String key = genKey(type, year);
                StockBean s = si.findMaxInYear(year);
                // 初始化：同类型同年份没有最大利益值
                if (!map.containsKey(key)) {
                    map.put(key, si.findMaxInYear(year));
                } else if (s != null && map.get(key).getBenefit() < s.getBenefit()) {
                    // 存在有些stock缺乏年月信息
                    map.put(key, s);
                }

            }
        }
        System.out.println(map);
        System.out.println("Multi:" + (System.currentTimeMillis() - start));
        return map;
    }

    private static String genKey(String type, int year) {
        return type + "_" + year;
    }


    public static void main(String[] args) {

        String dirpath = "F:\\codes\\java\\FileIO\\data\\stock data";
        String filename = "F:\\codes\\java\\FileIO\\data\\stock data\\sh600004.csv";
        test_file(filename);
    }
}
