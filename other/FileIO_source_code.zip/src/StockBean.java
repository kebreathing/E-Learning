/**
 * @author Chris 龙东恒
 * @mail kebreathing@gmail.com
 * @date 2017/11/18 13:09
 */
public class StockBean {

    private String code;        // index 0
    private String date;        // index 1
    private double open;        // index 2
    private double high;        // index 3
    private double low;         // index 4
    private double close;       // index 5
    private Double volume;        // index 7
    private Double money;         // index 8
    private int[] datearr;

    public StockBean(String code, String date, String open, String high, String low, String close, String volumn, String money) {
        this.code = code;
        this.date = date;
        this.open = Double.valueOf(open);
        this.high = Double.valueOf(high);
        this.low = Double.valueOf(low);
        this.close = Double.valueOf(close);
        this.volume = Double.valueOf(close);
        this.money = Double.valueOf(close);
        this.datearr = new int[3];
        strsToInts();
    }

    public StockBean(String code, String date, double open, double high, double low, double close, Double volume, Double money) {
        this.code = code;
        this.date = date;
        this.open = open;
        this.high = high;
        this.low = low;
        this.close = close;
        this.volume = volume;
        this.money = money;
        this.datearr = new int[3];
        strsToInts();
    }

    private void strsToInts() {
        if (date == null || date.length() == 0)
            return;
        String[] ds = null;
        if (date.contains("/"))
            ds = date.split("/");
        if(date.contains("-"))
            ds = date.split("-");

        try {
            for (int i = 0; i < ds.length; i++) {
                datearr[i] = Integer.valueOf(ds[i]);
            }
        } catch (NumberFormatException e){
            System.out.println(this);
            e.printStackTrace();
        }

    }

    public int[] getDatearr() {
        return datearr;
    }

    public void setDatearr(int[] datearr) {
        this.datearr = datearr;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public double getOpen() {
        return open;
    }

    public void setOpen(double open) {
        this.open = open;
    }

    public double getHigh() {
        return high;
    }

    public void setHigh(double high) {
        this.high = high;
    }

    public double getLow() {
        return low;
    }

    public void setLow(double low) {
        this.low = low;
    }

    public double getClose() {
        return close;
    }

    public void setClose(double close) {
        this.close = close;
    }

    public Double getVolume() {
        return volume;
    }

    public void setVolume(Double volume) {
        this.volume = volume;
    }

    public Double getMoney() {
        return money;
    }

    public void setMoney(Double money) {
        this.money = money;
    }

    public double getBenefit() {
        return this.close - this.open;
    }

    @Override
    public String toString() {
        return "StockBean{" +
                "code='" + code + '\'' +
                ", date='" + date + '\'' +
                ", open=" + open +
                ", high=" + high +
                ", low=" + low +
                ", close=" + close +
                ", volume=" + volume +
                ", money=" + money +
                '}';
    }

    public String writeToCSV_1_2(){
        return code + "," + datearr[0] +
                "," + date +
                "," + open +
                "," + close +
                "," + (close - open);
    }
    public String writeToCDV3(){
        return code +
                "," + date +
                "," + open +
                "," + close +
                "," + high +
                "," + low +
                "," + volume +
                "," + money;
    }
}
