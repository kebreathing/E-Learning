import java.util.Comparator;

/**
 * @author Chris 龙东恒
 * @mail kebreathing@gmail.com
 * @date 2017/11/18 14:01
 */
public class StockComparetor implements Comparator<StockBean> {
    @Override
    public int compare(StockBean o1, StockBean o2) {
        double oo1 = o1.getClose() - o1.getOpen();
        double oo2 = o2.getClose() - o2.getOpen();
        return Double.compare(oo2, oo1);
    }
}
