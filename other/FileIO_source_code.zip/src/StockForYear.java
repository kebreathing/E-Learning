import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Chris 龙东恒
 * @mail kebreathing@gmail.com
 * @date 2017/11/18 13:16
 */
public class StockForYear {
    private int year;
    private String code;
    private Map<Integer, List<StockBean>> month_stock_map;

    public StockForYear(String code, int year){
        this.code = code;
        this.year = year;
        this.month_stock_map = new HashMap<>(12);
        initMap();
    }

    private void initMap(){
        for(int i = 1; i <= 12; i++)
            month_stock_map.put(i, new ArrayList<>());
    }

    // 按月分类
    public void catalogByMonth(int month, int year, StockBean stockBean){
        if(this.year != year){
            return;
        }
        month_stock_map.get(month).add(stockBean);
    }

    public Map<Integer, List<StockBean>> getMonth_stock_map(){
        return this.month_stock_map;
    }
}
