import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

/**
 * @author Chris 龙东恒
 * @mail kebreathing@gmail.com
 * @date 2017/11/18 15:49
 */
public class CSVWriter {

    private static String HEAD1 = "code,year,date,open,close,earnings";
    private static String HEAD2 = "code,year,date,open,close,earnings";
    private static String HEAD3 = "code,date,open,close,high,low,volume,money";

    private void write(String savepath, String head, List<StockBean> ss, int type){
        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter(new FileWriter(new File(savepath)));
            writer.write(head+"\n");
            for(StockBean s : ss){
                switch (type){
                    case 1:
                    case 2:
                        writer.write(s == null? "\n" : s.writeToCSV_1_2() + "\n");
                        break;
                    case 3:
                        writer.write(s == null? "\n" : s.writeToCDV3() + "\n");
                        break;
                    default:
                        break;
                }
            }

        } catch (IOException e){
            e.printStackTrace();
        } finally {
            try {
                if(writer != null) {
                    writer.flush();
                    writer.close();
                }
            } catch (IOException e){
                e.printStackTrace();
            }
        }
    }

    public void write1(String savepath, List<StockBean> ss){
        write(savepath, HEAD1, ss, 1);
    }

    public void write2(String savepath, List<StockBean> ss){
        write(savepath, HEAD2, ss, 2);
    }

    public void write3(String savepath, List<StockBean> ss){
        write(savepath, HEAD3, ss, 3);
    }
}
