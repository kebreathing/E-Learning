import java.util.*;

/**
 * @author Chris 龙东恒
 * @mail kebreathing@gmail.com
 * @date 2017/11/18 13:42
 */
public class StockInfo {

    private String code;    // 股票编号
    private String type;    // 股票类型
    private Map<Integer, StockForYear> map;
    private Map<Integer, StockForYear> year_stock_map;


    public StockInfo(String code, String type, Map<Integer, StockForYear> map) {
        this.code = code;
        this.type = type;
        this.map = map;
        this.year_stock_map = new HashMap<>(map);
        sort_stocks();
    }

    public String getCode() {
        return code;
    }

    public String getType() {
        return type;
    }

    /**
     * 股票全排序
     */
    private void sort_stocks() {
        for (int year : year_stock_map.keySet()) {
            for (int month : year_stock_map.get(year).getMonth_stock_map().keySet()) {
                Collections.sort(year_stock_map.get(year).getMonth_stock_map().get(month), new StockComparetor());
            }
        }
    }

    /**
     * 返回指定年最大收益股票
     *
     * @param year
     * @return
     */
    public StockBean findMaxInYear(int year) {
        StockBean res = null;

        for (int i = 1; i <= 12; i++) {
            StockBean s = findMaxInYear_Month(year, i);
            if (s != null && res == null){
                res = s;
            } else if(s != null && res != null && res.getBenefit() < s.getBenefit()){
                res = s;
            }
        }
        return res;
    }

    // 返回第一元素 [ 降序排列 ]

    /**
     * 返回指定年指定月的最大收益
     *
     * @param year
     * @param month
     * @return
     */
    public StockBean findMaxInYear_Month(int year, int month) {
        StockBean res = null;
        try{
            if(!year_stock_map.containsKey(year) ||
                    !year_stock_map.get(year).getMonth_stock_map().containsKey(month) ||
                    year_stock_map.get(year).getMonth_stock_map().get(month).isEmpty())
                res = null;
            else
                res = year_stock_map.get(year).getMonth_stock_map().get(month).get(0);
        } catch (NullPointerException e){
            System.out.println(this + "{ " + year + "-" + month + " in findMaxInYear_Month");
            e.printStackTrace();
        }
        return res;
    }

    /**
     * 返回指定年月的股票数据
     *
     * @param year
     * @param month
     * @return
     */
    public List<StockBean> getStockInYear_Month(int year, int month) {
        if(month <= 0 && month > 12 || !map.containsKey(year))
            return null;
        return map.get(year).getMonth_stock_map().get(month);
    }

    @Override
    public String toString() {
        return "StockInfo{" +
                "code='" + code + '\'' +
                ", type='" + type + '\'' +
                '}';
    }
}
