import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Chris 龙东恒
 * @mail kebreathing@gmail.com
 * @date 2017/11/18 16:14
 */
public class Main {

    public static void all_maxearnings_in_years(int[] years, String dirname, String savepath){
        File dir = new File(dirname);
        if (!dir.isDirectory()) {
            System.out.println("{ " + dirname + " } is not a directory.");
            return;
        }

        List<StockBean> res = new ArrayList<>();
        for (File f : dir.listFiles()) {
            if (f.isFile()) {
                String name = f.getName();
                if (!name.substring(name.length() - 4, name.length()).equals(".csv")) {
                    System.out.println("{ " + name + " } is not csv file.");
                    continue;
                }

                StockInfo si = new CSVReader().read(f.getAbsolutePath());
                for(int year : years)
                    res.add(si.findMaxInYear(year));
            }
        }
        new CSVWriter().write1(savepath, res);
    }

    public static void type_maxearnings_in_years(int[] years, String dirname, String savepath){
        List<StockInfo> ss = new CSVReader().read_patch_thread(dirname);
        Map<String, StockBean> map = new HashMap<>();

        if (ss == null) {
            System.out.println("{ " + dirname + " } can not read from this directory.");
            return;
        }

        for (StockInfo si : ss) {
            String type = si.getType();
            for (int year : years) {
                String key = genKey(type, year);
                StockBean s = si.findMaxInYear(year);
                // 初始化：同类型同年份没有最大利益值
                if (!map.containsKey(key)) {
                    map.put(key, si.findMaxInYear(year));
                } else if (s != null && map.get(key).getBenefit() < s.getBenefit()) {
                    // 存在有些stock缺乏年月信息
                    map.put(key, s);
                }

            }
        }

        new CSVWriter().write2(savepath, new ArrayList<>(map.values()));
    }

    public static void stock_in_month_of_years(int[] months, int[] years, String dirname, String savepath){
        File dir = new File(dirname);
        if (!dir.isDirectory()) {
            System.out.println("{ " + dirname + " } is not a directory.");
            return;
        }

        List<StockBean> res = new ArrayList<>();
        for (File f : dir.listFiles()) {
            if (f.isFile()) {
                String name = f.getName();
                if (!name.substring(name.length() - 4, name.length()).equals(".csv")) {
                    System.out.println("{ " + name + " } is not csv file.");
                    continue;
                }

                System.out.print(f.getAbsolutePath());
                StockInfo si = new CSVReader().read(f.getPath());
                List<StockBean> list = si.getStockInYear_Month(2013,4);
                if(list != null)
                    res.addAll(list);
//                for(int year : years){
//                    for(int month : months){
//                        List<StockBean> list = si.getStockInYear_Month(year, month);
//                        if(list != null)
//                            res.addAll(list);
//                    }
//                }

            }
        }
        new CSVWriter().write3(savepath, res);
    }

    private static String genKey(String type, int year) {
        return type + "_" + year;
    }

    public static void main(String[] args){
        String dirpath = "F:\\codes\\java\\FileIO\\data\\stock data";
        String savepath= "F:\\codes\\java\\FileIO\\data\\stock ans";
//        all_maxearnings_in_years(new int[]{2013, 2014}, dirpath, savepath + "\\all_maxearnings_in_years.csv");
//        type_maxearnings_in_years(new int[]{2013, 2014}, dirpath, savepath + "\\type_maxearnings_in_years.csv");
        stock_in_month_of_years(new int[]{2013}, new int[]{4}, dirpath, savepath + "\\stock_in_month_of_years.csv");
    }
}
