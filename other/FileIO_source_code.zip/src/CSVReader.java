import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/**
 * @author Chris 龙东恒
 * @mail kebreathing@gmail.com
 * @date 2017/11/18 13:13
 */
public class CSVReader {

    // 读取csv文件信息
    // row 0: header skip
    // row 1 to EOF: information about Stocks

    /**
     * 从 filename 文件中读取，并存入字典 Map 中
     *
     * @param filename
     * @return 该股票各年的股票
     */
    public StockInfo read(String filename) {
        Map<Integer, StockForYear> map = new HashMap<>();
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(new File(filename)));
            // skip the header
            String line = reader.readLine();
            while ((line = reader.readLine()) != null) {
                // 获得股票数据
                String[] fields = line.split(",");
                StockBean stockBean = new StockBean(fields[0], fields[1], fields[2],
                        fields[3], fields[4], fields[5], fields[7], fields[8]);

                // 分类
                int[] dates = stockBean.getDatearr();
                if (!map.containsKey(dates[0])) {
                    map.put(dates[0], new StockForYear(fields[0], dates[0]));
                }
                map.get(dates[0]).catalogByMonth(dates[1], dates[0], stockBean);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        filename = (new File(filename)).getName();
        String code = filename.substring(0, filename.length() - 4);
        String type = filename.substring(0, 2);
        return new StockInfo(code, type, map);
    }

    /**
     * 单线程：批量读取数据文件
     * @param dirname
     * @return
     */
    public List<StockInfo> read_patch(String dirname) {
        List<StockInfo> list = new ArrayList<>();

        File dir = new File(dirname);
        if (!dir.isDirectory()) {
            System.out.println("{ " + dirname + " } is not a directory.");
            return null;
        }

        for (File f : dir.listFiles()) {
            if (f.isFile()) {
                String name = f.getName();
                if (!name.substring(name.length() - 4, name.length()).equals(".csv")) {
                    System.out.println("{ " + name + " } is not csv file.");
                    continue;
                }
//                System.out.println("{ " + name + " }  is read.");
                StockInfo si = read(f.getPath());
                list.add(si);
            }
        }

        return list;
    }

    /**
     * 多线程版读取目录下文件
     * @param dirname
     * @return
     */
    public List<StockInfo> read_patch_thread(String dirname) {
        List<StockInfo> list = Collections.synchronizedList(new ArrayList<>());

        File dir = new File(dirname);
        if (!dir.isDirectory()) {
            System.out.println("{ " + dirname + " } is not a directory.");
            return null;
        }

        for (File f : dir.listFiles()) {
            if (f.isFile()) {
                String name = f.getName();
                if (!name.substring(name.length() - 4, name.length()).equals(".csv")) {
                    System.out.println("{ " + name + " } is not csv file.");
                    continue;
                }
//                System.out.println("{ " + name + " }  is read.");
                new ReadThread(f.getPath(), list).run();
            }
        }

        return list;
    }

    class ReadThread extends Thread{

        String filename;
        List<StockInfo> stocks;

        public ReadThread(String filename, List<StockInfo> stocks){
            this.filename = filename;
            this.stocks = stocks;
        }

        @Override
        public void run() {
            synchronized (stocks){
                StockInfo si = read(this.filename);
                stocks.add(si);
            }
        }
    }
}
